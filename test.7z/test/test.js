	window.onload = () => {
		const firebaseConfig = {
	    apiKey: "AIzaSyBzdp5S3En4MgPS6HQvrmUvMpQeS2LgWso",
	    authDomain: "mario-plan-1d9ea.firebaseapp.com",
	    databaseURL: "https://mario-plan-1d9ea.firebaseio.com",
	    projectId: "mario-plan-1d9ea",
	    storageBucket: "mario-plan-1d9ea.appspot.com",
	    messagingSenderId: "976237185537",
	    appId: "1:976237185537:web:4562380cb51e1be194ce00"
  };
  
  firebase.initializeApp(firebaseConfig);
  const firestore = firebase.firestore();
  //console.log('firebase: ', firebase);
  //console.log('firestore: ', firestore);

  const docRef = firestore.doc('projects/test');

  const $input = document.querySelector('#test-input');
  const $h2 = document.querySelector('#h2-test');

  $input.onchange = function (e) {
  	console.log(e.target.value);
  	docRef.set({
  		value: e.target.value
  	})
  	.then(() => {console.log("Is set ", e.target.value)})
  	.catch((err) => {console.log("Is error ", err)})
  };

	  docRef.onSnapshot((doc) => {
	  	if (doc && doc.exists) {
	  		console.log(doc.data().value);
	  		$h2.innerText = doc.data().value;
	  	}
	  });



  };